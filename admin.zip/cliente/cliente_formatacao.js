/**
 * ============================================================
 * FORMATAÇÃO DA PLANILHA CLIENTE (SEM PROTEÇÃO / SEM FLAG)
 * ============================================================
 */

function cliente_formatarPlanilhaInterface_(spreadsheetId) {

  Logger.log('[CLIENTE][FORMATACAO] Início');

  if (!spreadsheetId) {
    throw new Error('ID da planilha cliente não informado.');
  }

  const ss = SpreadsheetApp.openById(spreadsheetId);

  let sheet = ss.getSheetByName('INFORMAÇÕES');
  if (!sheet) {
    sheet = ss.insertSheet('INFORMAÇÕES', 0);
  }

  ss.setActiveSheet(sheet);

  // LIMPAR SOMENTE A ÁREA CONTROLADA
  const area = sheet.getRange('A1:B20');
  area.clear();

  sheet.setHiddenGridlines(true);
  sheet.setColumnWidths(1, 2, 520);

  for (let i = 1; i <= 20; i++) {
    sheet.setRowHeight(i, 28);
  }

  sheet.getRange('A1')
    .setValue('INVENTÁRIO PATRIMONIAL')
    .setFontSize(18)
    .setFontWeight('bold');

  sheet.getRange('A3').setValue('Contexto de Trabalho').setFontWeight('bold');
  sheet.getRange('A6').setValue('📁 Pasta de Trabalho').setFontWeight('bold');
  sheet.getRange('A9').setValue('👤 Acessos').setFontWeight('bold');
  sheet.getRange('A14').setValue('▶️ Orientações').setFontWeight('bold');

  sheet.getRange('A15').setValue('• Utilize o menu da planilha para executar ações.');
  sheet.getRange('A16').setValue('• Envie fotos somente para a pasta indicada.');
  sheet.getRange('A17').setValue('• Não edite manualmente esta planilha.');

  sheet.setFrozenRows(20);

  Logger.log('[CLIENTE][FORMATACAO] Concluído');
}
